public class Salarydetails {
    private double salary;
    private double relief;

    // Constructor with parameters
    public Salarydetails(double salary, double relief) {
        this.salary = salary;
        this.relief = relief;
    }

    // Getter for salary
    public double getSalary() {
        return salary;
    }

    // Getter for relief
    public double getRelief() {
        return relief;
    }

    // Calculate SSNIT contribution (3.5% of salary)
    public double calculateSSNIT() {
        return 0.035 * salary;
    }

    // Calculate taxable salary
    public double calculateTaxableSalary() {
        return salary - (relief + calculateSSNIT());
    }
}

class EmployeeSalary extends Salarydetails{

    // Default constructor
    public EmployeeSalary() {
        super(0, 0);
    }

    // Constructor with parameters
    public EmployeeSalary(double salary, double relief) {
        super(salary, relief);
    }

    // Calculate income tax
    public double calculateIncomeTax() {
        double taxableIncome = calculateTaxableSalary();
        double tax = 0;

        if (taxableIncome <= 500) {
            tax = taxableIncome * 0.05;
        } else if (taxableIncome <= 1000) {
            tax = 500 * 0.05 + (taxableIncome - 500) * 0.125;
        } else {
            tax = 500 * 0.05 + 500 * 0.125 + (taxableIncome - 1000) * 0.175;
        }

        return tax;
    }

    // Calculate total deductions
    public double calculateTotalDeductions() {
        return calculateSSNIT() + calculateIncomeTax();
    }

    // Calculate net salary
    public double calculateNetSalary() {
        return getSalary() - calculateTotalDeductions();
    }
}