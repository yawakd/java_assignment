import javax.swing.JOptionPane;

public class SalaryTest {
    public static void main(String[] args) {
        String salaryInput = JOptionPane.showInputDialog("Enter your Salary:");
        String reliefInput = JOptionPane.showInputDialog("Enter your Tax Relief:");

        double salary = Double.parseDouble(salaryInput);
        double relief = Double.parseDouble(reliefInput);

        EmployeeSalary employee = new EmployeeSalary(salary, relief);

        String result = "Salary: " + employee.getSalary() + "\n" +
                "Tax Relief: " + employee.getRelief() + "\n" +
                "SSNIT Contribution: " + employee.calculateSSNIT() + "\n" +
                "Taxable Salary: " + employee.calculateTaxableSalary() + "\n" +
                "Income Tax: " + employee.calculateIncomeTax() + "\n" +
                "Total Deductions: " + employee.calculateTotalDeductions() + "\n" +
                "Net Salary: " + employee.calculateNetSalary();

        JOptionPane.showMessageDialog(null, result);
    }
}